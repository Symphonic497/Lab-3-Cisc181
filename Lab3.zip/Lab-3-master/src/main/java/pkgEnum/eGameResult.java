package pkgEnum;

public enum eGameResult {

	NATURAL, CRAPS, POINT, SEVEN_OUT;
}
