package pkgConstants;

public class Constants {
	public static final short ONE_OF_A_KIND = 1;
	public static final short TWO_OF_A_KIND = 2;
	public static final short THREE_OF_A_KIND = 3;
	public static final short FOUR_OF_A_KIND = 4;

}
