package pkgCore;

public abstract class HandScore {

	
}
